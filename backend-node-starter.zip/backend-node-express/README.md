# Database Setup

You'll need to have one of the following sql databases installed

1. MySQL
2. PostgreSQL
3. SQLite3

We provide some basic SQL files to create the appropriate tables in 
the `/db` directory for the supported databases.

# Server startup

```
$ npm start
```
