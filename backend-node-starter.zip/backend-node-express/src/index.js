const express = require('express');

const app = express();

/**
 * Route that serves the static content from the `frontned-reference` directory,
 * which contains the sample web client.
 */
app.use('/', express.static('../frontend-reference'));

/**
 * TODO: This is a stub implementation of the klist bugs API endppint
 */
app.get('/api/bugs', (req, res) => {
  res.json({bugs: []});
});

/**
 * Start the server via `npm start`
 */
app.listen(5000, () => {
  console.log('Listening on port 5000...');
});
